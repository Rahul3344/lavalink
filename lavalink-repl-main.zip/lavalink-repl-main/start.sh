curl -sL https://github.com/shyiko/jabba/raw/master/install.sh | bash -s -- --skip-rc && . ~/.jabba/jabba.sh
## use java 13 :3
jabba install openjdk@1.13.0-2
npm i
node index
