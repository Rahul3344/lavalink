---
name: Cannot connect
about: Create this issue if you cant connect
title: "[CANNOT CONNECT]"
labels: ''
assignees: ''

---

**What client do you use?**

**Are you sure using secure options?**

**Are you sure using port 443 when connecting?**
